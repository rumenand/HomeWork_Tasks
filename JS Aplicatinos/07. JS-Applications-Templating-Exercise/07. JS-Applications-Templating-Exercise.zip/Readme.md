Please start all projects with Live Server from folder
07. JS-Applications-Templating-Exercise.
This is because I don't want ton make copy of handlebars.min.js in every folder.

Thanks.