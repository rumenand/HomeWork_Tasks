const html = {
    tbody: () => document.querySelector('tbody'),
    formCtn: () => document.querySelector('form')
}
const printStudents = () => fetchData('students',{method:"GET"},[printTable]);
const getUrl = (x) => `https://remote-databases-homework.firebaseio.com/${x}.json`;
function fetchData(url,headers,callbacks){
    fetch(getUrl(url),headers)
    .then((res) => res.json())
    .then((data) => callbacks.forEach(x => x(data)))
    .catch((e) => console.log(e));
}
function printTable(data){
    html.tbody().innerHTML = '';
    sortAcsendingByID(data).forEach(x=>{
        const nRow = getEl('tr');
        nRow.appendChild(getEl('td',data[x].ID));
        nRow.appendChild(getEl('td',data[x].FirstName));
        nRow.appendChild(getEl('td',data[x].LastName));
        nRow.appendChild(getEl('td',data[x].FacultyNumber));
        nRow.appendChild(getEl('td',data[x].Grade));
        html.tbody().appendChild(nRow);
    })
}
function getEl(a,b){
    let el = document.createElement(a);
    if (b !== undefined) el.innerHTML = b;
    return el;
}
function sortAcsendingByID(data){
   return Object.keys(data).sort((a,b) => data[a].ID-data[b].ID);
}
function createStudent(e){
    e.preventDefault();
    const obj = getStudentObj();
    try{
        if (validateData(obj) === true){
            fetchData('students',{method: 'POST',
            body: JSON.stringify(obj)},[printStudents]);
        }
    }
    catch(err){alert(err);}
}
function validateData(obj){
    Object.keys(obj).forEach(x=>{
        if(obj[x] === undefined || obj[x] === null || obj[x] === ''){
            throw new Error(`Field ${x} cannot be empty!`);
        }
        if(x==='ID' || x==='Grade'){
        if (isNaN(obj[x])) throw new Error(`${x} must be a number!`);
        }
    })
    return true;
}
function getStudentObj(){
    const data = [...html.formCtn().querySelectorAll('input')]
                .map(x=>x.value);
    return{
        ID: data[0],
        FirstName:  data[1],
        LastName:   data[2],
        FacultyNumber:  data[3],
        Grade:  data[4]
    }
}
function initConent(){
    printStudents();
    html.formCtn().querySelector('button').addEventListener('click',createStudent);
}
initConent();