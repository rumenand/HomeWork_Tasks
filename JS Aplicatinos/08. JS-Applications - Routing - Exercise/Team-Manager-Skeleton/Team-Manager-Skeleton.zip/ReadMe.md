Install node modules bootstrap, sammy, handlebars before use the app.
Just type in terminal ->  npm i bootstrap sammy handlebars