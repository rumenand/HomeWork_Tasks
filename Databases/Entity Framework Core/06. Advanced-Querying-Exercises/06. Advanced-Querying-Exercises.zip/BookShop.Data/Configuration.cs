﻿namespace BookShop.Data
{
    internal class Configuration
    {
        internal static string ConnectionString 
            => "Server=localhost\\SQLEXPRESS01;Database=BookShop;Integrated Security=True;";
    }
}
