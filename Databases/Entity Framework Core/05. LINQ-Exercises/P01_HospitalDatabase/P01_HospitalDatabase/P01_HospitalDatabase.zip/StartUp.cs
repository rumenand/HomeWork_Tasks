﻿namespace P01_HospitalDatabase
{
    public class StartUp
    {
        static void Main()
        {
            
        }
    }
}
