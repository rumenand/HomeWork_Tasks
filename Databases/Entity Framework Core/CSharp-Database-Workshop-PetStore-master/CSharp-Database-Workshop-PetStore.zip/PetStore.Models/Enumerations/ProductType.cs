﻿namespace PetStore.Models.Enumerations
{
    public enum ProductType
    {
        Food = 1,
        Toy = 2,
        Decoration = 3,
    }
}
