﻿
namespace PetStore.ViewModels.Breed
{
    public class BreedViewModel
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
