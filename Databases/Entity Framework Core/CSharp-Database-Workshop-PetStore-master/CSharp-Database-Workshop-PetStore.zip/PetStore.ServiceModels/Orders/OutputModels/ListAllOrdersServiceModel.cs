﻿
namespace PetStore.ServiceModels.Orders.OutputModels
{
    public class ListAllOrdersServiceModel
    {
        public string Id { get; set; }

        public string Town { get; set; }

        public string Address { get; set; }
        public string Notes { get; set; }
    }
}
