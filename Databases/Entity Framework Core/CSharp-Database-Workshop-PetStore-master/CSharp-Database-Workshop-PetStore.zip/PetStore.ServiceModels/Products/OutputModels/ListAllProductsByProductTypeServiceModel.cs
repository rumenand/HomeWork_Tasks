﻿namespace PetStore.ServiceModels.Products.OutputModels
{
    public class ListAllProductsByProductTypeServiceModel
    {
        public string Name { get; set; }

        public decimal Price { get; set; }
    }
}
