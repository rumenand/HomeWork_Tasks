﻿
namespace PetStore.ServiceModels.Breeds
{
    public class BreedServiceModel
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
