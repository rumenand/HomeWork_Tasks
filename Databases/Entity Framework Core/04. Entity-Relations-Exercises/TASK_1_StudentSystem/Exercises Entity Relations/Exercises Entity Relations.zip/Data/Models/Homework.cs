﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace P01_StudentSystem.Data.Models
{
    public enum ContentType
    {
        Application = 1,
        Pdf = 2,
        Zip = 3
    }
    public class Homework
    {
        [Key]
        public int HomeworkId { get; set; }
        [Column(TypeName ="varchar(5000)")]
        public string Content { get; set; }
        [Required]
        public ContentType ContentType { get; set; }
        [Required]
        public DateTime SubmissionTime { get; set; }
        public int StudentId { get; set; }
        public Student Student { get; set; }
        public int CourseId { get; set; }
        public Course Course { get; set; }
    }
}
