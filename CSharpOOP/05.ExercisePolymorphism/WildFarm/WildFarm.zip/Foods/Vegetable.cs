﻿
namespace WildFarm.Foods
{
    public class Vegetable : Food
    {
        public Vegetable(int qty) : base(qty)
        {
        }
    }
}
