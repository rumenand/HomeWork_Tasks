﻿
namespace WildFarm.Foods
{
    public class Meat : Food
    {
        public Meat(int qty) : base(qty)
        {
        }
    }
}
