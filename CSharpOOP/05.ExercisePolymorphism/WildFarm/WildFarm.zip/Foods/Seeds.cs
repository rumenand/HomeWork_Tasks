﻿
namespace WildFarm.Foods
{
    public class Seeds : Food
    {
        public Seeds(int qty) : base(qty)
        {
        }
    }
}
