﻿
namespace _5BorderControl
{
    public interface IID
    {
        public string Id { get; set; }
    }
}
