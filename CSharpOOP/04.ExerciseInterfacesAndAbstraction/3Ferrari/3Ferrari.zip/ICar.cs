﻿

namespace _3Ferrari
{
    interface ICar
    {
            string OnBrakes();
            string OnGasPedal();        
    }
}
