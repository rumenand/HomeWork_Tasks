﻿
namespace Telephony
{
    interface IDialer
    {
        string Dial(string[] numbres);
    }
}
