﻿
namespace FoodShortage
{
    public interface IID
    {
        public string Id { get; set; }
    }
}
