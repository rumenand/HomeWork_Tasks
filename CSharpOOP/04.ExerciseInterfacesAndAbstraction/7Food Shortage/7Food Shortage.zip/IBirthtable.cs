﻿using System;

namespace FoodShortage
{
    public interface IBirthtable
    {
        public DateTime BirthDay { get; set; }
    }
}
