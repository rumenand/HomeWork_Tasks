﻿
namespace MilitaryElite
{
    interface ISolrier
    {
        int Id { get;}
        string FirstName { get;}
        string LastName { get;}
    }
}
