﻿using System.Collections.Generic;

namespace MilitaryElite
{
    public interface IEngineer
    {
        List<Repair> Repairs { get; }
    }
}
