﻿
namespace MilitaryElite
{
    public interface ILieutenantGeneral
    {
        Private [] ListPrivates { get; }
    }
}
