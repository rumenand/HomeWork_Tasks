﻿
namespace CollectionHierarchy
{
    public interface IAddRemoveCollection : IAddCollection
    {
        string Remove();
    }
}
