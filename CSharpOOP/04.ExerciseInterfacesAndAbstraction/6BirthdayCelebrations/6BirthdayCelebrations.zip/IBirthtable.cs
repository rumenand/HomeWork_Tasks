﻿using System;

namespace _6BirthdayCelebrations
{
    public interface IBirthtable
    {
        public DateTime BirthDay { get; set; }
    }
}
