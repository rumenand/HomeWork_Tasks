﻿
namespace _6BirthdayCelebrations
{
    public interface IID
    {
        public string Id { get; set; }
    }
}
