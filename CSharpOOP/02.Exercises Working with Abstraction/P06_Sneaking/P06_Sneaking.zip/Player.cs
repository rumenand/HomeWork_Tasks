﻿

namespace P06_Sneaking
{
    public class Player
    {
        public int XPos { get; set; }
        public int YPos { get; set; }

    }
}
