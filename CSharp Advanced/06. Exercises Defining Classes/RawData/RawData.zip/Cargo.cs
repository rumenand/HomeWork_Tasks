﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RawData
{
    class Cargo
    {
        public int CargoWeight { get; set; }
        public string CargoType { get; set; }
    }
}
