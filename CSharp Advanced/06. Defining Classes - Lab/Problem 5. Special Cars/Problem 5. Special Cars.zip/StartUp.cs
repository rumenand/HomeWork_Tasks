﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace CarManufacturer
{
    public class StartUp
    {
        public static void Main()
        {
            var tiresList = new List<Tire []>();
            string input;
            while((input = Console.ReadLine()) != "No more tires")
            {
                var tireInfo = input.Split();
                var tires = new Tire[tireInfo.Length/2];
                for (int i=0; i<tires.Length;i++)
                {
                    tires[i] = new Tire(int.Parse(tireInfo[i * 2]), double.Parse(tireInfo[i * 2 + 1]));                  
                }
                tiresList.Add(tires);
            }
            var enginesList = new List<Engine>();
            while((input = Console.ReadLine()) != "Engines done")
            {
                var engineInfo = input.Split();
                enginesList.Add(new Engine(int.Parse(engineInfo[0]), double.Parse(engineInfo[1])));
            }
            var carsList = new List<Car>();
            while ((input = Console.ReadLine()) != "Show special")
            {
                var carInfo = input.Split();
                carsList.Add(new Car(carInfo[0], carInfo[1], int.Parse(carInfo[2]), 
                    double.Parse(carInfo[3]), double.Parse(carInfo[4]),
                    enginesList[int.Parse(carInfo[5])], tiresList[int.Parse(carInfo[6])] ));
            }
            Func<Car, bool> checker = n => n.Year>=2017 
            && n.Engine.HorsePower>300 && (n.GetAllTiresPressure() >= 9) 
            && n.GetAllTiresPressure()<=10;
            var specialCars = carsList.Where(checker).ToList();
            foreach (var spCar in specialCars)
            {
                spCar.Drive(20);
                Console.WriteLine($"Make: {spCar.Make}");
                Console.WriteLine($"Model: {spCar.Model}");
                Console.WriteLine($"Year: {spCar.Year}");
                Console.WriteLine($"HorsePowers: {spCar.Engine.HorsePower}");
                Console.WriteLine($"FuelQuantity: {spCar.FuelQuantity}");
            }

            
        }
    }
}
