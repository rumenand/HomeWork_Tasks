﻿using System;

namespace CustomLinkedList2
{
    class Program
    {
        static void Main()
        {
            
        }
    }
}
