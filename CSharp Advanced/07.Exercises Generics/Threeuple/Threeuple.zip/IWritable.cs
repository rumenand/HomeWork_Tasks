﻿
namespace Threeuple
{
    interface IWritable
    {
        string WriteMe();
    }
}
