﻿
namespace ViceCity.Models.Players
{
    public class MainPlayer : Player
    {
        public MainPlayer() 
            : base("Tommy Vercetti", 100)
        {
        }
    }
}
